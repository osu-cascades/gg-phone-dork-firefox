# PhoneDork Firefox

A Firefox extension enabling a user to select a phone number in a web page, and
quickly execute searches with:

- Google
- Twillio

The Google search checks for the following number formats:

- XXXXXXXXXX
- (XXX) XXX-XXXX
- (XXX) XXX XXXX
- XXX.XXX.XXXX
- XXX-XXX-XXXX
- XXX XXX XXXX

## Contributors

Brian Christensen, @nielsentc, @xDOASx, @natkpie, @JWTappert, Andrew Bell, @Carson-Key, @domJalb, @cvlessis, @ybakos, @FrancescoAiello01, @ctsstc, @rasheedelkassed

(c) 2019 Guardian Group. All rights reserved.
